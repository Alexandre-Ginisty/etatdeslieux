package com.example.etatdeslieux

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.animation.TranslateAnimation
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val pieces = mutableListOf<Piece>()
    private lateinit var salleAdapter: SalleAdapter
    private lateinit var overlayLayout: FrameLayout
    private lateinit var actionButtonsLayout: LinearLayout
    private lateinit var deleteButton: Button
    private lateinit var openButton: Button
    private var selectedPiece: Piece? = null
    private var selectedPieceButton: Button? = null
    private lateinit var apiHandler: ApiHandler

    @SuppressLint("NotifyDataSetChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialisation des vues
        val editTextPieceName = findViewById<EditText>(R.id.editTextPieceName)
        val editTextPieceDescription = findViewById<EditText>(R.id.editTextPieceDescription)
        val editTextPieceSize = findViewById<EditText>(R.id.editTextPieceSize)
        val editTextPieceFloor = findViewById<EditText>(R.id.editTextPieceFloor)
        val editTextPieceCreator = findViewById<EditText>(R.id.editTextPieceCreator)

        val creerPieceButton = findViewById<Button>(R.id.creerPieceButton)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        overlayLayout = findViewById(R.id.overlayLayout)
        actionButtonsLayout = findViewById(R.id.actionButtonsLayout)
        deleteButton = findViewById(R.id.deleteButton)
        openButton = findViewById(R.id.openButton)
        apiHandler = ApiHandler(this)

        // Charger les pièces depuis SharedPreferences
        apiHandler.getPieces({ response ->
            pieces.clear()
            pieces.addAll(response)
            salleAdapter.notifyDataSetChanged()
        }, { error ->
            error.printStackTrace()
        })

        // Ajoutez des filtres pour restreindre l'entrée de texte
        editTextPieceName.filters = arrayOf(InputFilter.LengthFilter(255))
        editTextPieceDescription.filters = arrayOf(InputFilter.LengthFilter(1000))
        editTextPieceSize.filters = arrayOf(InputFilter.LengthFilter(10))
        editTextPieceFloor.filters = arrayOf(InputFilter.LengthFilter(3))
        editTextPieceCreator.filters = arrayOf(InputFilter.LengthFilter(255))

        salleAdapter = SalleAdapter(pieces, { piece ->
            // Clic normal : ouvrir la pièce
            val intent = Intent(this, SalleActivity::class.java)
            intent.putExtra("PIECE_NAME", piece.name)
            intent.putExtra("PIECE_DESCRIPTION", piece.description)
            intent.putExtra("PIECE_SIZE", piece.size)
            intent.putExtra("PIECE_FLOOR", piece.floor)
            intent.putExtra("PIECE_CREATOR", piece.creator)
            intent.putExtra("PIECE_ID", piece.id)
            startActivity(intent)
        }, { piece, button ->
            // Long clic : afficher les boutons de survol
            selectedPiece = piece
            selectedPieceButton = button
            showActionButtons(button)
        })

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = salleAdapter

        creerPieceButton.setOnClickListener {
            ajouterPiece(editTextPieceName, editTextPieceDescription, editTextPieceSize, editTextPieceFloor, editTextPieceCreator)
        }

        // Gérer les boutons de survol
        deleteButton.setOnClickListener {
            selectedPiece?.let { piece ->
                apiHandler.deletePiece(piece.id, {
                    pieces.remove(piece)
                    salleAdapter.notifyDataSetChanged()
                    hideActionButtons()
                    selectedPiece = null
                }, { error ->
                    error.printStackTrace()
                })
            }
        }

        openButton.setOnClickListener {
            selectedPiece?.let { piece ->
                val intent = Intent(this, SalleActivity::class.java)
                intent.putExtra("PIECE_NAME", piece.name)
                intent.putExtra("PIECE_DESCRIPTION", piece.description)
                intent.putExtra("PIECE_SIZE", piece.size)
                intent.putExtra("PIECE_FLOOR", piece.floor)
                intent.putExtra("PIECE_CREATOR", piece.creator)
                intent.putExtra("PIECE_ID", piece.id)
                startActivity(intent)
                hideActionButtons()
                selectedPiece = null
            }
        }

        overlayLayout.setOnClickListener {
            hideActionButtons()
        }
    }

    private fun ajouterPiece(nameField: EditText, descriptionField: EditText, sizeField: EditText, floorField: EditText, creatorField: EditText) {
        val name = nameField.text.toString()
        val description = descriptionField.text.toString()
        val size = sizeField.text.toString().toFloatOrNull() ?: 0f
        val floor = floorField.text.toString().toIntOrNull() ?: 0
        val creator = creatorField.text.toString()

        if (name.isNotEmpty() && description.isNotEmpty() && size > 0 && floor >= 0 && creator.isNotEmpty()) {
            val id = pieces.size + 1 // Génère un ID simple basé sur la taille de la liste
            val piece = Piece(id, name, description, size, floor, creator)
            apiHandler.insertPiece(piece, {
                apiHandler.getPieces({ response ->
                    pieces.clear()
                    pieces.addAll(response)
                    salleAdapter.notifyDataSetChanged()
                }, { error ->
                    error.printStackTrace()
                })
            }, { error ->
                error.printStackTrace()
            })
            nameField.text.clear()
            descriptionField.text.clear()
            sizeField.text.clear()
            floorField.text.clear()
            creatorField.text.clear()
        } else {
            Toast.makeText(this, "Veuillez entrer des informations valides pour la pièce", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showActionButtons(button: Button) {
        overlayLayout.visibility = FrameLayout.VISIBLE
        actionButtonsLayout.visibility = LinearLayout.VISIBLE
        val animation = TranslateAnimation(0f, 0f, -button.height.toFloat(), 0f)
        animation.duration = 300
        actionButtonsLayout.startAnimation(animation)
    }

    private fun hideActionButtons() {
        selectedPieceButton?.let { button ->
            val animation = TranslateAnimation(0f, 0f, 0f, -button.height.toFloat())
            animation.duration = 300
            actionButtonsLayout.startAnimation(animation)
        }
        overlayLayout.visibility = FrameLayout.GONE
        actionButtonsLayout.visibility = LinearLayout.GONE
    }
}

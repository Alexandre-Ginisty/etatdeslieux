package com.example.etatdeslieux

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Suppress("DEPRECATION")
class SalleActivity : AppCompatActivity() {

    private lateinit var currentPhotoPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_salle)

        val salleTitle = findViewById<TextView>(R.id.salleTitle)
        val salleDescription = findViewById<TextView>(R.id.salleDescription)
        val salleSize = findViewById<TextView>(R.id.salleSize)
        val salleFloor = findViewById<TextView>(R.id.salleFloor)
        val salleCreator = findViewById<TextView>(R.id.salleCreator)
        val imageView = findViewById<ImageView>(R.id.imageView)
        val takePhotoButton = findViewById<Button>(R.id.takePhotoButton)

        val name = intent.getStringExtra("PIECE_NAME")
        val description = intent.getStringExtra("PIECE_DESCRIPTION")
        val size = intent.getFloatExtra("PIECE_SIZE", 0f)
        val floor = intent.getIntExtra("PIECE_FLOOR", 0)
        val creator = intent.getStringExtra("PIECE_CREATOR")

        salleTitle.text = name
        salleDescription.text = description
        salleSize.text = "Taille: $size m²"
        salleFloor.text = "Étage: $floor"
        salleCreator.text = "Créateur: $creator"

        takePhotoButton.setOnClickListener {
            dispatchTakePictureIntent()
        }

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS
            )
        }
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    null
                }
                photoFile?.also {
                    val photoURI = FileProvider.getUriForFile(
                        this,
                        "com.example.etatdeslieux.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
                }
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            val imageView = findViewById<ImageView>(R.id.imageView)
            val bitmap = BitmapFactory.decodeFile(currentPhotoPath)
            imageView.setImageBitmap(bitmap)
            addToGallery()
        }
    }

    private fun addToGallery() {
        Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).also { mediaScanIntent ->
            val f = File(currentPhotoPath)
            mediaScanIntent.data = FileProvider.getUriForFile(this, "com.example.etatdeslieux.fileprovider", f)
            sendBroadcast(mediaScanIntent)
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val REQUEST_IMAGE_CAPTURE = 1
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }
}
